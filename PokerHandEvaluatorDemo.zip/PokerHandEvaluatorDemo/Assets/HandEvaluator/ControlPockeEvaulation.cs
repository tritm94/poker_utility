﻿using UnityEngine;
using HoldemHand;
using System;
public class ControlPockeEvaulation
{
    public static ControlPockeEvaulation _api;
    public static ControlPockeEvaulation api
    {
        get
        {
            if (_api == null)
            {
                _api = new ControlPockeEvaulation();
            }
            return _api;
        }
    }
    public void abc(){
        
    }
    private string pocket = "";
    private string board = "";
    private int opponents = 1;
    private double percentWin = 0f;
    // Use this for initialization
    public double showHandStreng(string pocketHand, string board, int opponents)
    {
        Opponents = opponents;
        Pocket = pocketHand;
        Board = board;
        ulong dead = Hand.ParseHand("");
        return WinOddsMonteCarlo(
                    Hand.ParseHand(Pocket), Hand.ParseHand(Board), dead, opponents, 1) * 100.0;
    }

    static double WinOddsMonteCarlo(
            ulong pocket, ulong board, ulong dead, int nopponents,
            double duration)
    {
        // Keep track of stats
        double win = 0.0, count = 0.0;

        // Keep track of time
        double start = Time.realtimeSinceStartup;
        // Loop for specified time duration
        while ((Time.realtimeSinceStartup - start) < duration)
        {
            // Player and board info
            //RandomHand (1,2)
            ulong boardmask = Hand.RandomHand(board, dead | pocket, 5);
            uint playerHandVal = Hand.Evaluate(pocket | boardmask);
            // Ensure that dead, board, and pocket cards are not
            // available to opponent hands.
            ulong deadmask = dead | boardmask | pocket;

            // Comparison Results
            bool greaterthan = true;
            bool greaterthanequal = true;
            // Get random opponent hand values
            for (int i = 0; i < nopponents; i++)
            {
                // Get Opponent hand info
                //RandomHand (1,2)
                ulong oppmask = Hand.RandomHand(deadmask, 2);
                uint oppHandVal = Hand.Evaluate(oppmask | boardmask);
                // Remove these opponent cards from future opponents
                deadmask |= oppmask;

                // Determine compare status
                if (playerHandVal < oppHandVal)
                {
                    greaterthan = greaterthanequal = false;
                    break;
                }
                else if (playerHandVal <= oppHandVal)
                {
                    greaterthan = false;
                }
            }

            // Calculate stats
            if (greaterthan)
                win += 1.0;
            else if (greaterthanequal)
                win += 0.5;

            count += 1.0;
        }

        // Return stats
        return (count == 0.0 ? 0.0 : win / count);
    }

    private int Opponents
    {
        get
        {
            return opponents;
        }

        set
        {
            opponents = value;

        }
    }

    private string Pocket
    {
        get { return pocket; }
        set
        {
            pocket = value;
        }
    }
    
    private string Board
    {
        get { return board; }
        set
        {
            board = value;
        }
    }
}


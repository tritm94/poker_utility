﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class TextScript : MonoBehaviour {
    private Text textDemo;
    // Use this for initialization
    void Start () {
        StartCoroutine(Example());
    }

    IEnumerator Example()
    {
        yield return new WaitForSeconds(0);
        print(Time.time);
        textDemo = GetComponent<Text>();
        textDemo.text = ControlPockeEvaulation.api.showHandStreng("Ac 4c", "th 7d 3c", 2).ToString();
        print(Time.time);
    }

}

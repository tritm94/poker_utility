﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class ControlMenu : MonoBehaviour {
    Button btnContolMenu;
    Toggle ckcSound, ckcVirate;
    GameObject controlMenu,horizontalSound, horizontalVirate;
    private bool isShow;
    void Awake(){
        init();
        btnContolMenu.onClick.AddListener(showHideMenu);
        ckcSound.onValueChanged.AddListener(listenEventSound);
    }

    private void listenEventSound(bool arg0)
    {
        if (arg0)
        {
            Debug.Log("Turn on");
        }
        else {
            Debug.Log("Turn Off");
            //Do some thing
        }
        
    }

    void init(){
        controlMenu = transform.Find("ControlMenu").gameObject;
        //Button Control
        btnContolMenu = transform.Find("Btn_Menu").GetComponent<Button>();
        //Sound
        horizontalSound = controlMenu.transform.Find("Horizontal_Sound").gameObject;
        ckcSound = horizontalSound.transform.Find("chk_sound").GetComponent<Toggle>();
        //Virate
        horizontalVirate = controlMenu.transform.Find("Horizontal_Vibrate").gameObject;
    }

    void showHideMenu(){
        isShow = !isShow;
        controlMenu.SetActive(isShow);
    }
}

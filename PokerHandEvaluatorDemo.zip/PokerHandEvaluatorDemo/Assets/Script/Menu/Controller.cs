﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using CoreFramework.Singleton;
//public class Controller : MonoBehaviour{

//    Button btnSoundOne,btnSoundTwo,btnSoundThree,btnSoundFour,btnSoundFive,btnSoundSix;
//    private void Awake()
//    {
//        inintView();
//        btnSoundOne.onClick.AddListener(playMusicOne);
//        btnSoundTwo.onClick.AddListener(playMusicTwo);

//        btnSoundThree.onClick.AddListener(playMusicThree);
//        btnSoundSix.onClick.AddListener(playMusicThree);

//        btnSoundFour.onClick.AddListener(playMusicFour);
//        btnSoundFive.onClick.AddListener(playMusicFive);
//    }

//    void inintView(){
//        btnSoundOne = transform.Find("Btn_Sound_1").GetComponent<Button>();
//		btnSoundTwo = transform.Find("Btn_Sound_2").GetComponent<Button>();
//		btnSoundThree = transform.Find("Btn_Sound_3").GetComponent<Button>();
//		btnSoundFour = transform.Find("Btn_Sound_4").GetComponent<Button>();
//		btnSoundFive = transform.Find("Btn_Sound_5").GetComponent<Button>();
//        btnSoundSix = transform.Find("Btn_Sound_1 (1)").GetComponent<Button>();
//    }

//    public void playMusicOne(){
//        SoundManager.SoundClick("Dice");
//    }


//	public void playMusicTwo()
//	{
//		SoundManager.SoundClick("Final");
//	}

//	public void playMusicThree()
//	{
//		SoundManager.SoundClick("Miss_turn");
//	}

//	public void playMusicFour()
//	{
//		SoundManager.SoundClick("Step_1");
//	}

//	public void playMusicFive()
//	{
//		SoundManager.SoundClick("Step_End");
//	}
//}

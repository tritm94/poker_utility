﻿namespace CoreFramework.Singleton{
		using UnityEngine;
		using System.Collections;
		
		public class MonoSingleton<T> : MonoBehaviour where T : MonoBehaviour{
			protected static T _instance;
			private static object _lock = new object();

			public static T Instance{
				get{
					if(_isApplicationQuit){
						return null;
					}

					lock(_lock){
						if(_instance == null){
							_instance = (T) FindObjectOfType( typeof(T) );
							if( FindObjectsOfType(typeof(T)).Length > 1 ){
								Debug.LogError("There is more than 1 instance of this class in scene view , please check it");

								return _instance;
							}

							if( _instance == null ){
								GameObject go = new GameObject("[" + typeof(T).ToString() + "]");

								_instance = go.AddComponent<T>();

								DontDestroyOnLoad(go);
							}
						}
					}

					return _instance;
				}
			}

			private bool _isPurged = false;
			private static bool _isApplicationQuit = false;

			public void OnDestroy(){
				CleanUp ();
			}

			public void Purged ( ){
				_isPurged = true;
				Destroy (this.gameObject);
			}

			public virtual void CleanUp( ){
				if (!_isPurged) {
					_isApplicationQuit = true;
				}
			}
		}
}
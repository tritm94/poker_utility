﻿using UnityEngine;
using System.Collections.Generic;
using CoreFramework.Singleton;

public class SoundManager :  MonoSingleton<SoundManager>{
    public static void SoundClick(string sound){
        SoundManager.Instance.PlaySound(sound);
    }

    public void PlaySound( string sound ){
        AudioSource audios = transform.GetComponent<AudioSource> ();
        AudioClip clip = Resources.Load<AudioClip> (sound);
        audios.PlayOneShot(clip);
    }



    private void Awake()
    {
        _instance = this;
        DontDestroyOnLoad(_instance.gameObject);
    }
}
